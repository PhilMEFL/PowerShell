# PsDriverManager

Find problem devices on your computer.

```diff
- You need to have at least .Net framework 4.5 installed to use this tool.
```

![alt text](https://4.bp.blogspot.com/-mX0VYWhZcCM/WXvTSNER7MI/AAAAAAAAEhk/oWqvwnx5fBkKQN0hpHKzCNqmEXL3NzXYgCLcBGAs/s1600/20170729_020949.gif)
