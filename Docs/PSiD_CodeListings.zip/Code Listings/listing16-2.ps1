﻿$test = Read-Host "Enter a number"
Write-host $tset
$a=[system.math]::PI*($tset*$test)
Write-Host "The area is $tset"
