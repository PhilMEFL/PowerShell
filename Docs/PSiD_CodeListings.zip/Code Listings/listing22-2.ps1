﻿function Do-That {
    Write-Host "Inside Do-That $var is '$var'"
    $var = 3
    Write-Host "Now, inside Do-That $var is '$var'"
}

Write-Host "Inside Test2 $var is '$var'"
$var = 2
Write-Host "Now, inside Test2 $var is '$var'"
Do-That
Write-Host "Back inside Test2 $var is '$var'"
