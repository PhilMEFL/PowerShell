﻿$test = Read-Host "Enter a number"
Write-Host $tset
