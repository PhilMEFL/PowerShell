function Get-COComputerInfo {
<#
.SYNOPSIS
Retrieves key computer information from AD and WMI
.DESCRIPTION
Get-COComputerInfo retrieves key computer information from both
Active Directory (AD), and from the computer itself using WMI. In
the case of a computer that is in AD but not available for the WMI
query, certain information in the output may be blank.

You need to specify a search path, and can specify more than one.
This can be an organizational unit (OU), or an entire domain.
The command will recurse all sub-OUs within whatever path(s) you
specify.
.PARAMETER searchBase
A string, or multiple strings, of locations to start looking for
computer objects in AD. Provide this in DN format, such as:
  'dc=company,dc=com','ou=sales,dc=company,dc=com'
.EXAMPLE
This example searches the Sales OU, and all sub-OUs:
  Get-COComputerInfo -searchBase 'ou=Sales,dc=company,dc=com'
.EXAMPLE
This example reads OU DNs from a text file, and searches them:
  Get-Content paths.txt | Get-COComputerInfo
#>
[CmdletBinding()]
  param(
      [Parameter(Mandatory=$true,ValueFromPipeline=$true)]
      [String[]]$searchBase
  )
  BEGIN {
      Write-Verbose "Loading ActiveDirectory module"
      Import-Module ActiveDirectory -Verbose:$false
  }
  PROCESS {
      Write-Debug "Starting PROCESS block"
      foreach ($ou in $searchBase) {
        
          Write-Verbose "Getting computers from $ou"
          $computers = Get-ADComputer -filter * -searchBase $ou `
                       -Properties Name,OperatingSystem,
                                   OperatingSystemVersion,
                                   OperatingSystemServicePack,
                                   passwordLastSet,whenCreated
        
          Write-Verbose "Got $($computers | measure | select -expand count)"
          foreach ($computer in $computers) {
            Try {
          
              Write-Verbose "WMI query to $computer"
              $wmi_worked = $true
              $cs = Get-WmiObject -Class Win32_ComputerSystem `
                    -ComputerName $computer.name -ErrorAction Stop
            } Catch {
          
              Write-Verbose "WMI query failed"
              $wmi_worked = $false
            }
          
            Write-Debug "Assembling property hash table"
            $properties = @{'ComputerName'=$computer.name;
                          'OS'=$computer.OperatingSystem;
                          'OSVersion'=$computer.OperatingSystemVersion;
                          'SPVersion'=$computer.OperatingSystemServicePack;
                          'WhenCreated'=$computer.whenCreated;
                          'PasswordLastSet'=$computer.passwordLastSet}
            if ($wmi_worked) {
              $properties += @{'Processors'=$cs.NumberOfProcessors;
                         'RAM'='{0:N}' -f ($cs.TotalPhysicalMemory / 1GB)}
            } else {
              $properties += @{'Processors'='';
                               'RAM'=''}
            }
          
            Write-Debug "Property hash table complete"
          
            $object = New-Object -TypeName PSObject -Property $properties
            $object.PSObject.TypeNames.Insert(0,'Company.ComputerInfo')
            Write-Output $object
          }
      }
  }
  END {}
}
