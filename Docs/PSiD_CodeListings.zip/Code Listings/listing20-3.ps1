﻿Get-Service
Get-Process
Get-Service
