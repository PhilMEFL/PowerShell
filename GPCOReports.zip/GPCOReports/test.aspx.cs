﻿using System;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class test : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{

	}
	protected void LinkButton_Click(object sender, EventArgs e)
	{
		string strNext = ((LinkButton)sender).ID;
		string[] strNum = Regex.Split(strNext, @"\D+");
		//control tblNext = this.Page.FindControl(strTable);
		HtmlLink link = Page.FindControl("GPCoStyle") as HtmlLink;
		//		link.Href = "GPcoStyleDetailed");
		//		HtmlGenericControl link = (HtmlGenericControl)Page.FindControl("styleSheet");
		//		var sheet =Page.getElementById('GPCoStyle');
		LinkButton objTable = (LinkButton)sender;
		Table1.Rows[0].CssClass = "Visible";
	}
}